import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

type Props = {
  column:      string;
  width:       number;
  minWidth:    number;
  onResize:    (e: React.MouseEvent, col: string) => void;
  onAutoFit:   (e: React.MouseEvent, col: string) => void;
  onFilter:    (e: React.MouseEvent, col: string) => void;
  isFiltered:  boolean;
  isPinned?:   boolean;
  pinnedLeft?: number;   // left offset untuk sticky header
  onPin?:      (col: string) => void;
  isEditable?: boolean;
  onToggleEditable?: (col: string) => void;
};

export function TableHeaderCell({
  column, width, minWidth, onResize, onAutoFit, onFilter, isFiltered,
  isPinned = false, pinnedLeft, onPin, isEditable = false, onToggleEditable,
}: Props) {
  const {
    attributes, listeners, setNodeRef,
    transform, transition, isDragging,
  } = useSortable({ id: column });

  const stickyStyle: React.CSSProperties = {
    position: "sticky",
    top: 0,
    zIndex: isPinned ? 30 : 20,
    background: "var(--table-head-bg)",
    ...(isPinned ? {
      left: pinnedLeft ?? 0,
      boxShadow: "2px 0 4px rgba(0,0,0,0.08)",
    } : {}),
  };

  const style: React.CSSProperties = {
    // Kalau pinned: JANGAN apply transform dari dnd-kit agar tidak bergeser
    transform: isPinned ? undefined : CSS.Translate.toString(transform),
    transition,
    width: `${width}px`,
    minWidth: `${minWidth}px`,
    maxWidth: `${width}px`,
    opacity: isDragging ? 0.75 : 1,
    ...stickyStyle,
  };

  // Pinned column: tidak bisa di-drag (tidak spread listeners/attributes)
  const dragProps = isPinned ? {} : { ...attributes, ...listeners };

  return (
    <th
      ref={setNodeRef}
      {...dragProps}
      className="relative select-none group th-table-head"
      style={{
        ...style,
        padding: "10px 12px",
        borderBottom: "2px solid var(--border)",
        borderRight: "1px solid var(--border)",
        cursor: isPinned ? "default" : "grab",
      } as any}
    >
      <style>{`
        .group:hover .filter-btn { opacity: 0.5 !important; }
        .group:hover .filter-btn:hover { opacity: 1 !important; color: var(--accent) !important; background: var(--accent-soft); }
        .group:hover .pin-btn { opacity: 0.5 !important; }
        .group:hover .pin-btn:hover { opacity: 1 !important; color: var(--accent) !important; background: var(--accent-soft); }
        .group:hover .edit-column-btn { opacity: 0.5 !important; }
        .group:hover .edit-column-btn:hover { opacity: 1 !important; color: var(--accent) !important; background: var(--accent-soft); }
        .group:focus-within .edit-column-btn { opacity: 0.5 !important; }
      `}</style>

      <div className="flex items-center justify-between gap-1 overflow-hidden">
        <span className="truncate flex-1 text-[11px] font-bold uppercase tracking-wider"
          style={{ color: isPinned ? "var(--accent)" : isDragging ? "var(--accent)" : "var(--text-secondary)" }}
          title={column}>
          {isPinned && (
            <span className="mr-1 opacity-60">📌</span>
          )}
          {column}
        </span>

        <div className="flex items-center gap-0.5 shrink-0">
          {/* Pin icon */}
          {onPin && (
            <button
              onPointerDown={e => e.stopPropagation()}
              onClick={() => onPin(column)}
              className="p-0.5 rounded transition-all shrink-0 pin-btn"
              style={{
                color:   isPinned ? "var(--accent)" : "var(--text-muted)",
                opacity: isPinned ? 1 : 0,
              }}
              title={isPinned ? "Unpin kolom" : "Pin kolom (freeze kiri)"}
            >
              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
                <path d="M16 12V4h1V2H7v2h1v8l-2 2v2h5.2v6h1.6v-6H18v-2l-2-2z"/>
              </svg>
            </button>
          )}

          {/* Filter icon */}
          <button
            onPointerDown={e => e.stopPropagation()}
            onClick={e => onFilter(e, column)}
            className="p-0.5 rounded transition-all shrink-0 filter-btn"
            style={{
              color:   isFiltered ? "var(--accent)" : "var(--text-muted)",
              opacity: isFiltered ? 1 : 0,
            }}
            title="Filter kolom"
          >
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M3 3a1 1 0 011-1h12a1 1 0 011 1v3a1 1 0 01-.293.707L12 11.414V15a1 1 0 01-.293.707l-2 2A1 1 0 018 17v-5.586L3.293 6.707A1 1 0 013 6V3z" clipRule="evenodd" />
            </svg>
          </button>

          {/* Editable-column toggle */}
          {onToggleEditable && (
            <button
              onPointerDown={e => e.stopPropagation()}
              onClick={() => onToggleEditable(column)}
              className="p-0.5 rounded transition-all shrink-0 edit-column-btn"
              style={{
                color:   isEditable ? "var(--accent)" : "var(--text-muted)",
                opacity: isEditable ? 1 : 0,
              }}
              title={isEditable ? "Nonaktifkan edit kolom" : "Aktifkan edit kolom"}
              aria-label={isEditable ? `Nonaktifkan edit kolom ${column}` : `Aktifkan edit kolom ${column}`}
              aria-pressed={isEditable}
            >
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="m16.862 4.487 1.687-1.688a2.121 2.121 0 0 1 3 3L10.582 16.766a4.5 4.5 0 0 1-1.897 1.13l-3.164.949.949-3.164a4.5 4.5 0 0 1 1.13-1.897l9.262-9.297Z" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 7.125 17.25 4.875" />
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Resize handle — tetap ada walau pinned */}
      <div
        onPointerDown={e => e.stopPropagation()}
        onMouseDown={e => onResize(e, column)}
        onDoubleClick={e => onAutoFit(e, column)}
        className="resize-handle group-hover:bg-blue-500"
        style={{ opacity: 0.35 }}
        title="Geser / Klik 2x auto-fit"
      />
    </th>
  );
}
