import { useState } from "react";
import teskomApi, { AutoFillResult } from "../../services/teskomApi";
import { useAuthStore } from "../../state/authStore";

interface Props {
  onAutofill: (data: AutoFillResult["autofill"]) => void;
  onToast: (msg: string, type?: "success" | "error") => void;
}

export default function AutoFillSearch({ onAutofill, onToast }: Props) {
  const [query, setQuery]   = useState("");
  const [node, setNode]     = useState<"TERMINATING" | "ORIGINATING">("TERMINATING");
  const [loading, setLoading] = useState(false);

  const { user }    = useAuthStore();
  const isPtl       = user?.role === "ptl";
  const sourceLabel = isPtl ? "GSheet PTL" : "database";

  const handleSearch = async () => {
    const trimmed = query.trim();
    if (!trimmed) return;
    setLoading(true);
    try {
      const result = isPtl
        ? await teskomApi.autofillPtl(trimmed)
        : await teskomApi.autofill(trimmed, node);

      onAutofill(result.autofill);
      onToast(
        `Data ID PA "${trimmed}" (${node}) berhasil dimuat dari ${sourceLabel}`,
        "success"
      );
    } catch (err: any) {
      const msg = err?.response?.data?.detail || `ID PA "${trimmed}" tidak ditemukan`;
      onToast(msg, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 rounded-xl mb-4" style={{ background: "var(--accent-soft)", border: "1px solid var(--accent)" }}>
      <div className="flex items-center gap-2 mb-2">
        <svg className="w-4 h-4 shrink-0" style={{ color: "var(--accent)" }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
        <span className="text-sm font-semibold" style={{ color: "var(--accent)" }}>
          Auto-fill dari {sourceLabel}
        </span>
      </div>
      <p className="text-xs mb-3" style={{ color: "var(--text-secondary)" }}>
        {isPtl
          ? "Masukkan ID PA untuk mengisi form dari GSheet PTL kamu."
          : "Masukkan ID PA untuk mengisi form dari database."}
      </p>
      <div className="flex gap-2">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
          placeholder="Contoh: A121101000105"
          className="flex-1 px-3 py-2 rounded-lg text-sm border"
          style={{
            background: "var(--bg-surface)",
            border: "1px solid var(--border)",
            color: "var(--text-primary)",
            outline: "none",
          }}
          onFocus={(e) => (e.target.style.borderColor = "var(--accent)")}
          onBlur={(e) => (e.target.style.borderColor = "var(--border)")}
        />

        {/* Node selector — hanya tampil untuk non-PTL */}
        {!isPtl && (
          <select
            value={node}
            onChange={(e) => setNode(e.target.value as "TERMINATING" | "ORIGINATING")}
            className="px-3 py-2 rounded-lg text-sm border"
            style={{
              background: "var(--bg-surface)",
              border: "1px solid var(--border)",
              color: "var(--text-primary)",
              outline: "none",
              cursor: "pointer",
            }}
          >
            <option value="TERMINATING">TERMINATING</option>
            <option value="ORIGINATING">ORIGINATING</option>
          </select>
        )}

        <button
          onClick={handleSearch}
          disabled={loading || !query.trim()}
          className="px-4 py-2 rounded-lg text-sm font-semibold text-white transition-opacity"
          style={{ background: "var(--accent)", opacity: loading || !query.trim() ? 0.5 : 1 }}
        >
          {loading ? "Mencari..." : "Cari"}
        </button>
      </div>
    </div>
  );
}
