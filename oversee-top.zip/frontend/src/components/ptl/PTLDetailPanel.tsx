/**
 * PTLDetailPanel.tsx
 * Panel "Detail Pekerjaan" untuk PTL — setara dengan Engineer.
 * Preset kolom sekarang disimpan di DB via usePresets("ptl").
 * activePresetId tetap di localStorage (useActivePresetStore).
 *
 * Drill-down: saat masuk dari PTL Dashboard (via appStore.ptlDrillFilter),
 * filter langsung diterapkan dan banner info ditampilkan.
 */
import { useEffect, useState, useMemo, useCallback } from "react";
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors, type DragEndEvent } from "@dnd-kit/core";
import { SortableContext, horizontalListSortingStrategy, arrayMove } from "@dnd-kit/sortable";
import { useThemeStore }     from "../../state/themeStore";
import { useAuthStore }      from "../../state/authStore";
import { useToast }          from "../../utils/useToast";
import { usePresets }        from "../../hooks/usePresets";
import { useAppearanceStore } from "../../state/appearanceStore";
import { useAppStore }        from "../../state/appStore";
import { useTaskStore }       from "../../state/taskStore";
import { useTableSettings }    from "../../hooks/useTableSettings";
import { calcAging, DEFAULT_THRESHOLDS } from "../../utils/aging";
import type { AgingThresholds } from "../../utils/aging";
import { getAgingThresholds } from "../../services/settingsApi";
import Sidebar               from "../layout/Sidebar";
import Topbar                from "../layout/Topbar";
import ToastContainer        from "../ui/ToastContainer";
import PTLKanbanBoard        from "./PTLKanbanBoard";
import ColumnFilter          from "../table/ColumnFilter";
import PresetEditorModal     from "../preset/PresetEditorModal";
import { TableHeaderCell }   from "../table/TableHeaderCell";
import TableToolbar          from "../table/TableToolbar";
import { TablePagination }   from "../table/TablePagination";
import EditableCell          from "../table/EditableCell";
import MobileRecordList       from "../table/MobileRecordList";
import MobileFilterSheet      from "../table/MobileFilterSheet";
import api                   from "../../services/api";
import baiApi                from "../../services/baiApi";

import type { SheetRecord, PTLSheetData, StatusMaster } from "../../state/taskStore";

// ─── Types ────────────────────────────────────────────────────────────────────
type DetailView = "kanban" | "table";
const DEFAULT_COL_WIDTH = 160;
const MIN_COL_WIDTH     = 60;

// ─── BAI Button ───────────────────────────────────────────────────────────────
function PtlBaiButton({ rowId, idPa, namaPerusahaan, onToast }: {
  rowId: number; idPa: string; namaPerusahaan: string;
  onToast: (msg: string, type?: "success" | "error") => void;
}) {
  const [showModal, setShowModal] = useState(false);
  const today = new Date().toISOString().split("T")[0];
  const [tanggal, setTanggal] = useState(today);
  const [loading, setLoading] = useState(false);

  const handleGenerate = async () => {
    setLoading(true);
    try {
      const blob = await baiApi.generateBaiPtl(rowId, tanggal);
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href     = url; a.download = `BAI_${idPa.replace(/\//g, "-")}.docx`; a.click();
      URL.revokeObjectURL(url);
      onToast(`BAI ${idPa} berhasil digenerate!`, "success");
      setShowModal(false);
    } catch (err: any) {
      if (err?.response?.data instanceof Blob) {
        const text = await err.response.data.text();
        try { onToast(JSON.parse(text).detail || "Gagal generate BAI", "error"); }
        catch { onToast("Gagal generate BAI", "error"); }
      } else {
        onToast(err?.response?.data?.detail || "Gagal generate BAI", "error");
      }
    } finally { setLoading(false); }
  };

  return (
    <>
      <button onClick={e => { e.stopPropagation(); setShowModal(true); }}
        title={`Generate BAI — ${idPa}`}
        className="flex items-center justify-center w-6 h-6 rounded-md transition-all"
        style={{ color: "var(--text-muted)" }}
        onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "var(--accent-soft)"; (e.currentTarget as HTMLElement).style.color = "var(--accent)"; }}
        onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "var(--text-muted)"; }}>
        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      </button>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: "rgba(0,0,0,0.5)" }}
          onClick={e => { if (e.target === e.currentTarget) setShowModal(false); }}>
          <div className="rounded-2xl shadow-2xl p-6 w-full max-w-sm mx-4"
            style={{ background: "var(--bg-surface)", border: "1px solid var(--border)" }}>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: "var(--accent-soft)" }}>
                <svg className="w-5 h-5" style={{ color: "var(--accent)" }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <div className="min-w-0">
                <h3 className="font-bold text-sm" style={{ color: "var(--text-primary)" }}>Generate BAI</h3>
                <p className="text-xs truncate" style={{ color: "var(--text-muted)" }}>{namaPerusahaan || idPa}</p>
              </div>
              <button onClick={() => setShowModal(false)} className="ml-auto shrink-0 p-1 rounded-lg"
                style={{ color: "var(--text-muted)" }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = "var(--bg-surface2)"}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = "transparent"}>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="px-3 py-2.5 rounded-lg mb-4 text-xs" style={{ background: "var(--bg-surface2)", border: "1px solid var(--border)" }}>
              <span style={{ color: "var(--text-muted)" }}>No. PA: </span>
              <span className="font-semibold" style={{ color: "var(--text-primary)" }}>{idPa}</span>
            </div>
            <div className="mb-5">
              <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
                Tanggal BAI <span className="font-normal" style={{ color: "var(--text-muted)" }}>(default hari ini)</span>
              </label>
              <input type="date" value={tanggal} onChange={e => setTanggal(e.target.value)}
                className="w-full px-3 py-2 rounded-lg text-sm border"
                style={{ background: "var(--bg-surface2)", border: "1px solid var(--border)", color: "var(--text-primary)", outline: "none" }}
                onFocus={e => e.target.style.borderColor = "var(--accent)"}
                onBlur={e => e.target.style.borderColor = "var(--border)"} />
            </div>
            <div className="flex gap-2">
              <button onClick={() => setShowModal(false)} disabled={loading}
                className="flex-1 px-4 py-2.5 rounded-xl text-sm font-medium"
                style={{ background: "var(--bg-surface2)", color: "var(--text-secondary)", border: "1px solid var(--border)" }}>
                Batal
              </button>
              <button onClick={handleGenerate} disabled={loading}
                className="flex-1 px-4 py-2.5 rounded-xl text-sm font-semibold text-white flex items-center justify-center gap-2"
                style={{ background: "var(--accent)", opacity: loading ? 0.7 : 1 }}>
                {loading ? <><span className="spinner" /> Membuat...</> : <>Ya, Generate</>}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ─── Teskom Button ────────────────────────────────────────────────────────────
function PtlTeskomButton({ idPa }: { idPa: string }) {
  const setNavPage        = useAppStore(s => s.setPage);
  const setTeskomAutofill = useAppStore(s => s.setTeskomAutofill);
  return (
    <button onClick={e => { e.stopPropagation(); if (!idPa) return; setTeskomAutofill(idPa); setNavPage("teskom"); }}
      title={`Buka Teskom — ${idPa}`}
      className="flex items-center justify-center w-6 h-6 rounded-md transition-all"
      style={{ color: "var(--text-muted)" }}
      onMouseEnter={e => { (e.currentTarget as HTMLElement).style.background = "var(--accent-soft)"; (e.currentTarget as HTMLElement).style.color = "var(--accent)"; }}
      onMouseLeave={e => { (e.currentTarget as HTMLElement).style.background = "transparent"; (e.currentTarget as HTMLElement).style.color = "var(--text-muted)"; }}>
      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
      </svg>
    </button>
  );
}

// ─── Drill Banner ─────────────────────────────────────────────────────────────
function DrillBanner({ label, onClear }: { label: string; onClear: () => void }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-xl shrink-0"
      style={{ background: "var(--accent-soft)", border: "1px solid var(--accent)22" }}>
      <svg className="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}
        style={{ color: "var(--accent)" }}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L13 13.414V19a1 1 0 01-.553.894l-4 2A1 1 0 017 21v-7.586L3.293 6.707A1 1 0 013 6V4z" />
      </svg>
      <span className="text-xs font-medium flex-1" style={{ color: "var(--accent)" }}>
        Filter aktif dari Dashboard: <strong>{label}</strong>
      </span>
      <button onClick={onClear}
        className="text-[10px] px-2 py-0.5 rounded-md font-medium"
        style={{ background: "var(--accent)", color: "#fff" }}>
        Hapus Filter
      </button>
    </div>
  );
}

// ─── Main Panel ───────────────────────────────────────────────────────────────
export default function PTLDetailPanel() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [view, setView]                         = useState<DetailView>("table");
  const [localRecords, setLocalRecords]         = useState<SheetRecord[]>([]);
  const [search, setSearch]                     = useState("");
  const [saving, setSaving]                     = useState(false);
  const [thresholds, setThresholds]             = useState<AgingThresholds>(DEFAULT_THRESHOLDS);

  const { pageSize, tablePage, setPageSize, setTablePage } = useTableSettings(20);

  const [activeFilters, setActiveFilters]       = useState<Record<string, string[]>>({});
  const [activeFilterCol, setActiveFilterCol]   = useState<string | null>(null);
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);
  const [filterPos, setFilterPos]               = useState({ top: 0, left: 0 });
  const [presetDropdownOpen, setPresetDropdown] = useState(false);
  const [showCreatePreset, setShowCreatePreset] = useState(false);
  const [editingPresetId, setEditingPresetId]   = useState<number | null>(null);
  const [drillLabel, setDrillLabel]             = useState<string | null>(null);

  const { theme }                   = useThemeStore();
  const { user }                    = useAuthStore();
  const { toasts, show: showToast } = useToast();

  const { ptlEditableColumns, togglePtlEditableColumn, loadPtlEditableColumnsFromDB } = useAppearanceStore();

  const ptlSheetData          = useTaskStore((s) => s.ptlSheetData);
  const setPtlSheetData       = useTaskStore((s) => s.setPtlSheetData);
  const ptlLoading            = useTaskStore((s) => s.ptlLoading);
  const setPtlLoading         = useTaskStore((s) => s.setPtlLoading);
  const statusMaster          = useTaskStore((s) => s.statusMaster);
  const refreshAll            = useTaskStore((s) => s.refreshAll);

  const ptlDrillFilter     = useAppStore(s => s.ptlDrillFilter);
  const clearPtlDrillFilter = useAppStore(s => s.clearPtlDrillFilter);
  const setPage            = useAppStore(s => s.setPage);

  const {
    presets,
    activePreset,
    activePresetId,
    setActivePresetId,
    updatePreset,
    loading: presetLoading,
    refetch: refetchPresets,
  } = usePresets("ptl");

  const columns = activePreset?.columns ?? [];
  const widths  = activePreset?.widths  ?? {};
  const pinnedColumns = activePreset?.pinnedColumns ?? [];

  const handleTogglePin = (col: string) => {
    if (!activePreset) return;
    const current   = activePreset.pinnedColumns ?? [];
    const cols      = activePreset.columns ?? [];
    const isPinning = !current.includes(col);
    if (isPinning) {
      const nextPinned = [...current, col];
      const unpinned   = cols.filter(c => !nextPinned.includes(c));
      updatePreset(activePreset.id, { pinnedColumns: nextPinned, columns: [...nextPinned, ...unpinned] });
    } else {
      updatePreset(activePreset.id, { pinnedColumns: current.filter(c => c !== col) });
    }
  };

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  useEffect(() => {
    console.log("[PTLDetail] ptlSheetData changed:", ptlSheetData);
    if (ptlSheetData?.records) {
      console.log("[PTLDetail] Setting localRecords:", ptlSheetData.records.length);
      setLocalRecords(ptlSheetData.records);
    }
  }, [ptlSheetData]);

  useEffect(() => { loadPtlEditableColumnsFromDB(); }, []);
  useEffect(() => {
    getAgingThresholds().then(setThresholds).catch(() => {});
  }, []);

  useEffect(() => {
    if (!ptlDrillFilter) return;
    const { column, values, label } = ptlDrillFilter;
    if (column === "__aging_tier") {
      setActiveFilters({ ["__aging_tier"]: values });
    } else {
      setActiveFilters({ [column]: values });
    }
    setDrillLabel(label ?? `${column} = ${values.join(", ")}`);
    setTablePage(1);
    clearPtlDrillFilter();
  }, [ptlDrillFilter]);

  const allColumns = ptlSheetData?.columns ?? [];
  const records    = localRecords;
  const idPaCol    = allColumns.find(c => c === "ID PA") ?? "ID PA";
  const namaCol    = allColumns.find(c => c.toLowerCase().includes("perusahaan")) ?? "";
  const tglCol     = "TGL TERBIT PA";
  const baiCol     = "TGL UPLOAD BAI";
  const statusPaCol = "Status PA";

  const statusCol = statusMaster?.status_column ?? "Status Pekerjaan";
  const detailCol = statusMaster?.detail_column ?? "Detail Progres";

  const refreshPtlData = useCallback(async () => {
    try {
      const [statusRes, sheetRes] = await Promise.all([
        api.get("/status"),
        api.get<PTLSheetData>("/records/ptl-sheet")
      ]);
      useTaskStore.getState().fetchStatusMaster();
      setPtlSheetData(sheetRes.data);
      if (sheetRes.data.records) {
        setLocalRecords(sheetRes.data.records);
      }
    } catch (err) {
      console.error("[PTLDetail] refreshPtlData error:", err);
      showToast("Gagal memuat data GSheet", "error");
    }
  }, [showToast, setPtlSheetData]);

  useEffect(() => {
    if (!ptlSheetData?.records && !ptlLoading) {
      console.log("[PTLDetail] No data in store, fetching...");
      refreshPtlData();
    }
  }, [ptlSheetData, ptlLoading, refreshPtlData]);

  const handleUpdateCell = useCallback(async (rowId: number, col: string, value: string) => {
    setLocalRecords(prev =>
      prev.map(r => r.row_id === rowId ? { ...r, data: { ...r.data, [col]: value } } : r)
    );
    setSaving(true);
    try {
      await api.post(`/records/ptl-sheet/${rowId}/cells`, { updates: { [col]: value } });
      await refreshPtlData();
    } catch (err: any) {
      setLocalRecords(prev =>
        prev.map(r => r.row_id === rowId ? { ...r, data: { ...r.data, [col]: localRecords.find(s => s.row_id === rowId)?.data[col] ?? value } } : r)
      );
      showToast(err?.response?.data?.detail ?? "Gagal menyimpan", "error");
    } finally {
      setSaving(false);
    }
  }, [showToast, refreshPtlData, localRecords]);

  const handleUpdateStatus = useCallback(async (rowId: number, status: string, detail?: string) => {
    setLocalRecords(prev =>
      prev.map(r => {
        if (r.row_id !== rowId) return r;
        return {
          ...r,
          data: {
            ...r.data,
            [statusCol]: status,
            ...(detail !== undefined ? { [detailCol]: detail } : {}),
          },
        };
      })
    );
    setSaving(true);
    try {
      await api.post(`/records/ptl-sheet/${rowId}/cells`, {
        updates: {
          [statusCol]: status,
          ...(detail !== undefined ? { [detailCol]: detail } : {}),
        },
      });
      await refreshPtlData();
    } catch (err: any) {
      showToast(err?.response?.data?.detail ?? "Gagal menyimpan status", "error");
      await refreshPtlData();
    } finally {
      setSaving(false);
    }
  }, [statusCol, detailCol, showToast, refreshPtlData]);

  const handleRefresh = async () => {
    try {
      setPtlLoading(true);
      const res = await api.get<PTLSheetData>("/records/ptl-sheet");
      setPtlSheetData(res.data);
      if (res.data.records) {
        setLocalRecords(res.data.records);
      }
      showToast("Data diperbarui", "success");
    } catch {
      showToast("Gagal memuat data GSheet", "error");
    } finally {
      setPtlLoading(false);
    }
  };

  // ── Filter + search — termasuk aging tier virtual ──
  const filteredRecords = useMemo(() => {
    let result = [...records];

    const normalFilters = Object.fromEntries(
      Object.entries(activeFilters).filter(([k]) => k !== "__aging_tier")
    );
    if (Object.keys(normalFilters).length > 0) {
      result = result.filter(r =>
        Object.entries(normalFilters).every(([key, vals]) => vals.includes(String(r.data[key] || "")))
      );
    }

    // Filter aging tier virtual — pakai tglUploadBAI + statusPa agar freeze konsisten
    if (activeFilters["__aging_tier"]) {
      const tiers = activeFilters["__aging_tier"];
      result = result.filter(r => {
        const aging = calcAging(
          r.data[tglCol],
          thresholds,
          r.data[baiCol],
          r.data[statusPaCol]
        );
        return aging ? tiers.includes(aging.tier) : false;
      });
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(r => Object.values(r.data ?? {}).some(v => String(v).toLowerCase().includes(q)));
    }
    return result;
  }, [records, search, activeFilters, thresholds]);

  const totalPage    = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  const pagedRecords = filteredRecords.slice((tablePage - 1) * pageSize, tablePage * pageSize);
  const filterCount  = Object.keys(activeFilters).length;

  const toggleFilter = (key: string, val: string) => {
    setActiveFilters(prev => {
      const cur  = prev[key] || [];
      const next = cur.includes(val) ? cur.filter(v => v !== val) : [...cur, val];
      const upd  = { ...prev };
      if (next.length === 0) delete upd[key]; else upd[key] = next;
      return upd;
    });
    setDrillLabel(null);
  };

  const handleResetFilter = () => {
    setActiveFilters({});
    setDrillLabel(null);
  };

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (activePreset && over && active.id !== over.id) {
      const oi      = columns.indexOf(active.id as string);
      const ni      = columns.indexOf(over.id as string);
      const newCols = arrayMove(columns, oi, ni);
      updatePreset(activePreset.id, { columns: newCols });
    }
  };

  const onColResize = (e: React.MouseEvent, col: string) => {
    e.preventDefault(); e.stopPropagation();
    const startX = e.clientX;
    const startW = widths[col] ?? DEFAULT_COL_WIDTH;
    const ghost  = document.createElement("div");
    Object.assign(ghost.style, { position: "fixed", top: "0", bottom: "0", width: "2px", background: "#2563eb", zIndex: "99999", left: `${e.clientX}px`, pointerEvents: "none" });
    document.body.appendChild(ghost);
    const onMove = (ev: MouseEvent) => { ghost.style.left = `${ev.clientX}px`; };
    const onUp   = (ev: MouseEvent) => {
      document.body.removeChild(ghost);
      const newW = Math.max(MIN_COL_WIDTH, startW + (ev.clientX - startX));
      if (activePreset) updatePreset(activePreset.id, { widths: { ...widths, [col]: newW } });
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
    };
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
  };

  const onColAutoFit = (e: React.MouseEvent, col: string) => {
    e.stopPropagation();
    if (!activePreset) return;
    const canvas = document.createElement("canvas");
    const ctx    = canvas.getContext("2d")!;
    ctx.font     = "bold 12px sans-serif";
    let max      = ctx.measureText(col).width + 40;
    ctx.font     = "12px sans-serif";
    records.forEach(r => { const w = ctx.measureText(String(r.data[col] || "")).width; if (w > max) max = w; });
    updatePreset(activePreset.id, { widths: { ...widths, [col]: Math.min(600, max + 24) } });
  };

  const handleOpenFilter = (e: React.MouseEvent, col: string) => {
    const rect        = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const POPUP_W     = 268;
    const POPUP_MAX_H = 420;
    const vw          = window.innerWidth;
    const vh          = window.innerHeight;
    const left = rect.left + POPUP_W > vw ? Math.max(4, vw - POPUP_W - 8) : rect.left;
    const top  = rect.bottom + 5 + POPUP_MAX_H > vh ? Math.max(4, rect.top - POPUP_MAX_H - 4) : rect.bottom + 5;
    setFilterPos({ top, left });
    setActiveFilterCol(prev => prev === col ? null : col);
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ background: "var(--bg-app)" }}>
      <Sidebar collapsed={sidebarCollapsed} onToast={showToast} />

      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Topbar onRefresh={handleRefresh} sidebarCollapsed={sidebarCollapsed}
          onToggleSidebar={() => setSidebarCollapsed(v => !v)} />

        <main className="flex-1 overflow-hidden flex flex-col">

          <TableToolbar
            title="Detail Pekerjaan"
            recordCount={records.length}
            userName={user?.nama_lengkap ?? ""}
            saving={saving}
            onRefresh={handleRefresh}
            view={view}
            onViewChange={setView}
            search={search}
            onSearch={v => { setSearch(v); setTablePage(1); }}
            presets={presets.map(p => ({ id: p.id, name: p.name, columns: p.columns ?? [] }))}
            activePreset={activePreset ? { id: activePreset.id, name: activePreset.name, columns: activePreset.columns ?? [] } : null}
            presetLoading={presetLoading}
            onSelectPreset={id => setActivePresetId(id as number)}
            onCreatePreset={() => setShowCreatePreset(true)}
            onEditPreset={id => setEditingPresetId(id as number)}
            filterCount={filterCount}
            onResetFilter={handleResetFilter}
            onOpenMobileFilter={() => setMobileFilterOpen(true)}
            filteredCount={filteredRecords.length}
            totalCount={records.length}
          />

          {/* Mobile: selalu gunakan card list. Kanban tidak ditampilkan di mobile. */}
          <div className="md:hidden flex-1 min-h-0 overflow-y-auto custom-scrollbar px-3 pb-3">
            {drillLabel && (
              <div className="mb-2.5">
                <DrillBanner label={drillLabel} onClear={handleResetFilter} />
              </div>
            )}

            {!activePreset ? (
              <div className="flex min-h-40 flex-col items-center justify-center rounded-2xl p-6 text-center"
                style={{ background: "var(--bg-surface)", border: "2px dashed var(--border)" }}>
                <p className="text-sm font-medium" style={{ color: "var(--text-secondary)" }}>
                  {presetLoading ? "Memuat preset..." : "Belum ada preset kolom"}
                </p>
              </div>
            ) : (
              <MobileRecordList
                records={pagedRecords}
                columns={columns}
                statusMaster={statusMaster}
                canEditColumn={col => ptlEditableColumns.includes(col) && col !== statusCol && col !== detailCol}
                onCommit={handleUpdateCell}
                onStatusChange={handleUpdateStatus}
                renderActions={record => (
                  <>
                    <PtlBaiButton
                      rowId={record.row_id}
                      idPa={record.data[idPaCol] ?? ""}
                      namaPerusahaan={namaCol ? (record.data[namaCol] ?? "") : ""}
                      onToast={showToast}
                    />
                    <PtlTeskomButton idPa={record.data[idPaCol] ?? ""} />
                  </>
                )}
              />
            )}

          </div>

          {filteredRecords.length > 0 && (
            <div className="md:hidden shrink-0 px-3 pb-3">
              <TablePagination
                page={tablePage}
                pageSize={pageSize}
                totalPage={totalPage}
                total={filteredRecords.length}
                setPage={setTablePage}
                setPageSize={setPageSize}
              />
            </div>
          )}

          {/* Desktop: behavior existing tetap dipertahankan, termasuk Kanban. */}
          <div className="hidden md:flex flex-1 overflow-hidden flex-col">
            {view === "kanban" && (
              <div className="flex-1 overflow-hidden">
                {ptlLoading && localRecords.length === 0
                  ? <div className="p-6 text-xs" style={{ color: "var(--text-muted)" }}>Memuat data...</div>
                  : <PTLKanbanBoard records={records} onUpdateCell={handleUpdateCell} />
                }
              </div>
            )}

            {view === "table" && (
              <div className="flex-1 overflow-hidden flex flex-col px-4 pt-3 pb-4 gap-2.5">

              {drillLabel && (
                <DrillBanner label={drillLabel} onClear={handleResetFilter} />
              )}

              {!activePreset ? (
                <div className="flex-1 flex flex-col items-center justify-center rounded-2xl"
                  style={{ background: "var(--bg-surface)", border: "2px dashed var(--border)" }}>
                  <p className="text-sm font-medium mb-3" style={{ color: "var(--text-secondary)" }}>
                    {presetLoading ? "Memuat preset..." : "Belum ada preset kolom"}
                  </p>
                  {!presetLoading && (
                    <button onClick={() => setShowCreatePreset(true)}
                      className="px-4 py-2 rounded-xl text-sm font-semibold text-white"
                      style={{ background: "var(--accent)" }}>
                      + Buat Preset
                    </button>
                  )}
                </div>
              ) : (
                <>
                  <div className="flex-1 overflow-auto custom-scrollbar rounded-2xl" style={{ border: "1px solid var(--border)" }}>
                    <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                      <table className="text-xs" style={{ tableLayout: "fixed", width: "max-content", borderCollapse: "separate", borderSpacing: 0 }}>
                        <colgroup>
                          <col style={{ width: "72px", minWidth: "72px" }} />
                          {columns.map(col => (
                            <col key={col} style={{ width: `${widths[col] ?? DEFAULT_COL_WIDTH}px`, minWidth: `${MIN_COL_WIDTH}px` }} />
                          ))}
                        </colgroup>
                        <thead>
                          <tr>
                            <th className="sticky top-0 left-0 th-table-head"
                              style={{ zIndex: 30, width: 72, minWidth: 72, maxWidth: 72, padding: "10px 8px", borderBottom: "2px solid var(--border)", borderRight: "1px solid var(--border)", textAlign: "center", background: "var(--table-head-bg)" }}>
                              <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color: "var(--text-muted)" }}>Aksi</span>
                            </th>
                            <SortableContext items={columns} strategy={horizontalListSortingStrategy}>
                              {columns.map(col => (
                                <TableHeaderCell key={col} column={col}
                                  width={widths[col] ?? DEFAULT_COL_WIDTH}
                                  minWidth={MIN_COL_WIDTH}
                                  onResize={onColResize}
                                  onAutoFit={onColAutoFit}
                                  onFilter={handleOpenFilter}
                                  isFiltered={(activeFilters[col]?.length ?? 0) > 0}
                                  isPinned={pinnedColumns.includes(col)}
                                  pinnedLeft={pinnedColumns.includes(col)
                                    ? 72 + pinnedColumns.slice(0, pinnedColumns.indexOf(col)).reduce(
                                        (acc, c) => acc + (widths[c] ?? DEFAULT_COL_WIDTH), 0
                                      )
                                    : undefined}
                                  onPin={handleTogglePin}
                                  isEditable={ptlEditableColumns.includes(col)}
                                  onToggleEditable={togglePtlEditableColumn}
                                />
                              ))}
                            </SortableContext>
                          </tr>
                        </thead>
                        <tbody>
                          {pagedRecords.map((r, rowIdx) => {
                            const idPaVal = r.data[idPaCol] ?? "";
                            const namaVal = namaCol ? (r.data[namaCol] ?? "") : "";
                            return (
                              <tr key={r.row_id} className="th-table-row"
                                style={{ background: rowIdx % 2 !== 0 ? "var(--table-row-alt)" : "var(--bg-surface)" }}>
                                <td className="sticky left-0"
                                  style={{ zIndex: 10, width: 72, minWidth: 72, padding: "4px 8px", textAlign: "center", borderRight: "1px solid var(--border)", borderBottom: "1px solid var(--border)", background: rowIdx % 2 !== 0 ? "var(--table-row-alt)" : "var(--bg-surface)" }}>
                                  <div className="flex items-center justify-center gap-0.5">
                                    <PtlBaiButton rowId={r.row_id} idPa={idPaVal} namaPerusahaan={namaVal} onToast={showToast} />
                                    <PtlTeskomButton idPa={idPaVal} />
                                  </div>
                                </td>
                                {columns.map(col => {
                                  const colW         = widths[col] ?? DEFAULT_COL_WIDTH;
                                  const isStatusCol  = col === statusCol;
                                  const isDetailCol  = col === detailCol;
                                  const isEditable   = ptlEditableColumns.includes(col) && !isStatusCol && !isDetailCol;
                                  const currentVal   = r.data[col] ?? "";
                                  const isPinned     = pinnedColumns.includes(col);
                                  const pinnedLeft   = isPinned
                                    ? 72 + pinnedColumns.slice(0, pinnedColumns.indexOf(col)).reduce(
                                        (acc, c) => acc + (widths[c] ?? DEFAULT_COL_WIDTH), 0
                                      )
                                    : undefined;

                                  return (
                                    <td key={col}
                                      className="overflow-hidden"
                                      style={{
                                        borderRight: "1px solid var(--border)",
                                        borderBottom: "1px solid var(--border)",
                                        width: colW,
                                        minWidth: MIN_COL_WIDTH,
                                        maxWidth: colW,
                                        padding: "8px 12px",
                                        ...(isPinned ? {
                                          position: "sticky",
                                          left: pinnedLeft,
                                          zIndex: 10,
                                          background: rowIdx % 2 !== 0 ? "var(--table-row-alt)" : "var(--bg-surface)",
                                          boxShadow: "2px 0 4px rgba(0,0,0,0.06)",
                                        } : {}),
                                      }}
                                      title={currentVal}>

                                      {isStatusCol && statusMaster && (
                                        <select value={currentVal}
                                          onChange={e => handleUpdateStatus(r.row_id, e.target.value, undefined)}
                                          className="text-xs border rounded px-1 py-0.5 w-full"
                                          style={{ background: "var(--bg-surface2)", color: "var(--text-primary)", borderColor: "var(--border)" }}>
                                          <option value="">-</option>
                                          {(statusMaster.primary ?? []).map(s => (
                                            <option key={s} value={s}>{s}</option>
                                          ))}
                                        </select>
                                      )}

                                      {isDetailCol && statusMaster && (
                                        <select value={currentVal}
                                          onChange={e => handleUpdateStatus(r.row_id, r.data[statusCol] ?? "", e.target.value)}
                                          className="text-xs border rounded px-1 py-0.5 w-full"
                                          style={{ background: "var(--bg-surface2)", color: "var(--text-primary)", borderColor: "var(--border)" }}>
                                          <option value="-">-</option>
                                          {(statusMaster.mapping?.[r.data[statusCol]] ?? []).map(o => (
                                            <option key={o} value={o}>{o}</option>
                                          ))}
                                        </select>
                                      )}

                                      {isEditable && !isStatusCol && !isDetailCol && (
                                        <EditableCell
                                          value={currentVal}
                                          colW={colW}
                                          onCommit={val => handleUpdateCell(r.row_id, col, val)}
                                        />
                                      )}

                                      {!isStatusCol && !isDetailCol && !isEditable && (
                                        <div className="truncate px-2 py-1 text-xs"
                                          style={{ color: "var(--text-secondary)", maxWidth: `${colW - 8}px` }}>
                                          {currentVal || "—"}
                                        </div>
                                      )}
                                    </td>
                                  );
                                })}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </DndContext>
                  </div>

                  <div className="flex items-center justify-between px-3 py-2 rounded-xl shrink-0"
                    style={{ background: "var(--bg-surface)", border: "1px solid var(--border)" }}>
                    <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                      <b style={{ color: "var(--text-primary)" }}>
                        {(tablePage - 1) * pageSize + 1}–{Math.min(tablePage * pageSize, filteredRecords.length)}
                      </b>{" "}dari <b style={{ color: "var(--text-primary)" }}>{filteredRecords.length}</b>
                    </span>
                    <div className="flex items-center gap-2">
                      <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setTablePage(1); }}
                        className="th-select text-xs py-1">
                        <option value={20}>20/hal</option>
                        <option value={50}>50/hal</option>
                        <option value={100}>100/hal</option>
                      </select>
                      <div className="flex gap-1">
                        <button disabled={tablePage === 1} onClick={() => setTablePage(1)} className="btn-ghost px-2 py-1 text-xs disabled:opacity-30">«</button>
                        <button disabled={tablePage === 1} onClick={() => setTablePage(p => p - 1)} className="btn-ghost px-2 py-1 text-xs disabled:opacity-30">‹</button>
                        <span className="px-3 py-1 text-xs font-medium rounded-lg" style={{ background: "var(--accent)", color: "#fff" }}>{tablePage}</span>
                        <button disabled={tablePage === totalPage} onClick={() => setTablePage(p => p + 1)} className="btn-ghost px-2 py-1 text-xs disabled:opacity-30">›</button>
                        <button disabled={tablePage === totalPage} onClick={() => setTablePage(totalPage)} className="btn-ghost px-2 py-1 text-xs disabled:opacity-30">»</button>
                      </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
          </div>
        </main>
      </div>

      <ToastContainer toasts={toasts} />

      <MobileFilterSheet
        open={mobileFilterOpen}
        columns={columns}
        records={records}
        activeFilters={activeFilters}
        onToggle={(col, val) => {
          toggleFilter(col, val);
          setTablePage(1);
        }}
        onReset={() => {
          handleResetFilter();
          setTablePage(1);
        }}
        onClose={() => setMobileFilterOpen(false)}
      />

      {activeFilterCol && (
        <ColumnFilter
          column={activeFilterCol}
          records={records}
          activeFilters={activeFilters}
          onToggle={toggleFilter}
          onClose={() => setActiveFilterCol(null)}
          position={filterPos}
        />
      )}

      {showCreatePreset && (
        <PresetEditorModal
          scope="ptl"
          allCols={allColumns}
          initialColumns={allColumns}
          onSaved={refetchPresets}
          onClose={() => setShowCreatePreset(false)}
        />
      )}

      {editingPresetId !== null && (
        <PresetEditorModal
          presetId={editingPresetId}
          scope="ptl"
          allCols={allColumns}
          onSaved={refetchPresets}
          onClose={() => setEditingPresetId(null)}
        />
      )}

    </div>
  );
}
