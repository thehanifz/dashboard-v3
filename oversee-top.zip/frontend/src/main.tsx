import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

import ErrorBoundary from "./components/ui/ErrorBoundary";
import { initHashNavigation } from "./state/appStore";

initHashNavigation();

ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
).render(
  <React.StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </React.StrictMode>
);

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch((error) => {
      console.warn("OverSee PWA service worker registration failed:", error);
    });
  });
}
