/**
 * ProfilePage.tsx
 * Halaman profil untuk semua role termasuk superuser.
 * Data dari /api/profile/me — superuser return dari token, user biasa dari DB.
 */
import { useEffect, useState } from "react";
import { profileApi, ProfileData } from "../services/profileApi";
import { authApi } from "../services/authApi";
import { useAuthStore } from "../state/authStore";
import { useAppStore } from "../state/appStore";

const ROLE_LABEL: Record<string, string> = {
  engineer:  "Engineer",
  ptl:       "PTL",
  mitra:     "Mitra",
  superuser: "Superuser",
};
const ROLE_COLOR: Record<string, string> = {
  engineer:  "#2563eb",
  ptl:       "#7c3aed",
  mitra:     "#059669",
  superuser: "#d97706",
};

export default function ProfilePage() {
  const { user, beginLogout, clearAuth } = useAuthStore();
  const { setPage }           = useAppStore();

  const [profile, setProfile]           = useState<ProfileData | null>(null);
  const [loading, setLoading]           = useState(true);
  const [loggingOut, setLoggingOut]     = useState(false);

  // Password form
  const [curPwd, setCurPwd]         = useState("");
  const [newPwd, setNewPwd]         = useState("");
  const [conPwd, setConPwd]         = useState("");
  const [pwdLoading, setPwdLoading] = useState(false);
  const [pwdError, setPwdError]     = useState("");
  const [pwdSuccess, setPwdSuccess] = useState("");

  // GSheet form (PTL only)
  const [gsheetUrl, setGsheetUrl]         = useState("");
  const [gsheetSheet, setGsheetSheet]     = useState("");
  const [gsLoading, setGsLoading]         = useState(false);
  const [gsError, setGsError]             = useState("");
  const [gsSuccess, setGsSuccess]         = useState("");
  const [gsNeedShare, setGsNeedShare]     = useState(false);
  const [gsServiceEmail, setGsServiceEmail] = useState("");
  const [gsCreatedCols, setGsCreatedCols] = useState<string[]>([]);

  useEffect(() => {
    profileApi.getMe()
      .then((data) => {
        setProfile(data);
        setGsheetUrl(data.gsheet_url ?? "");
        setGsheetSheet(data.gsheet_sheet_name ?? "");
      })
      .catch(() => {
        // Fallback ke data dari authStore jika API gagal
        if (user) {
          setProfile({
            username:          user.username,
            nama_lengkap:      user.nama_lengkap,
            role:              user.role,
            is_active:         true,
            gsheet_url:        null,
            gsheet_sheet_name: null,
            created_at:        null,
            created_by:        null,
          });
        }
      })
      .finally(() => setLoading(false));
  }, []);

  const handleLogout = async () => {
    setLoggingOut(true);
    beginLogout();
    try {
      await authApi.logout();
    } catch {
      // Logout lokal tetap dilanjutkan; beginLogout() mencegah session
      // recovery/auto-refresh menghidupkan kembali session yang baru ditutup.
    }
    clearAuth();
    window.location.href = "/";
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdError(""); setPwdSuccess("");
    setPwdLoading(true);
    try {
      const res = await profileApi.changePassword({
        current_password: curPwd,
        new_password:     newPwd,
        confirm_password: conPwd,
      });
      setPwdSuccess(res.message);
      setCurPwd(""); setNewPwd(""); setConPwd("");
      setTimeout(() => handleLogout(), 2000);
    } catch (err: any) {
      setPwdError(err?.response?.data?.detail ?? "Gagal mengubah password");
    } finally {
      setPwdLoading(false);
    }
  };

  const handleUpdateGSheet = async (e: React.FormEvent) => {
    e.preventDefault();
    setGsError(""); setGsSuccess(""); setGsNeedShare(false); setGsCreatedCols([]);
    setGsLoading(true);
    try {
      const res = await profileApi.updateGSheet({
        gsheet_url:        gsheetUrl.trim() || null,
        gsheet_sheet_name: gsheetSheet.trim() || null,
      });
      setGsServiceEmail(res.service_email ?? "");
      if (res.need_share) {
        setGsNeedShare(true);
      } else {
        setGsCreatedCols(res.created_columns ?? []);
        setGsSuccess("GSheet info berhasil disimpan");
      }
    } catch (err: any) {
      setGsError(err?.response?.data?.detail ?? "Gagal menyimpan");
    } finally {
      setGsLoading(false);
    }
  };

  const isSuperuser = user?.role === "superuser";
  const role        = profile?.role ?? user?.role ?? "engineer";
  const roleLabel   = ROLE_LABEL[role] ?? role;
  const roleColor   = ROLE_COLOR[role] ?? "#2563eb";
  const namaLengkap = profile?.nama_lengkap ?? user?.nama_lengkap ?? "—";
  const username    = profile?.username ?? user?.username ?? "—";

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center" style={{ background: "var(--bg-app)" }}>
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>Memuat profil...</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto" style={{ background: "var(--bg-app)" }}>
      <div className="max-w-2xl mx-auto p-6 space-y-5">

        {/* Header */}
        {!isSuperuser && (
          <button onClick={() => setPage("dashboard")}
            className="flex items-center gap-2 text-sm font-medium"
            style={{ color: "var(--text-secondary)" }}>
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
            </svg>
            Kembali
          </button>
        )}

        {/* Info Akun */}
        <div className="rounded-2xl border p-6" style={{ background: "var(--bg-surface)", borderColor: "var(--border)" }}>
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-bold text-white shrink-0 shadow-sm"
              style={{ background: roleColor }}>
              {namaLengkap.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <h1 className="text-lg font-bold leading-tight" style={{ color: "var(--text-primary)" }}>
                {namaLengkap}
              </h1>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <span className="text-sm" style={{ color: "var(--text-secondary)" }}>@{username}</span>
                <span className="inline-block text-[11px] font-semibold px-2 py-0.5 rounded-lg"
                  style={{ background: `${roleColor}18`, color: roleColor }}>
                  {roleLabel}
                </span>
              </div>
            </div>
          </div>

          {/* Detail grid */}
          <div className="mt-5 grid grid-cols-2 gap-3">
            {[
              { label: "Username",    value: username },
              { label: "Status",      value: profile?.is_active ? "Aktif" : "Nonaktif" },
              { label: "Dibuat oleh", value: profile?.created_by ?? "—" },
              {
                label: "Bergabung",
                value: profile?.created_at
                  ? new Date(profile.created_at).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })
                  : "—"
              },
            ].map((item) => (
              <div key={item.label} className="rounded-xl p-3"
                style={{ background: "var(--bg-surface2)", border: "1px solid var(--border)" }}>
                <p className="text-[10px] font-semibold uppercase tracking-wider" style={{ color: "var(--text-muted)" }}>
                  {item.label}
                </p>
                <p className="text-sm font-medium mt-0.5" style={{ color: "var(--text-primary)" }}>
                  {item.value}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* GSheet — PTL only */}
        {role === "ptl" && (
          <div className="rounded-2xl border p-6" style={{ background: "var(--bg-surface)", borderColor: "var(--border)" }}>
            <h2 className="text-sm font-bold mb-4" style={{ color: "var(--text-primary)" }}>Google Sheet</h2>

            {gsError && <Alert type="error" msg={gsError} />}
            {gsSuccess && <Alert type="success" msg={gsSuccess} />}

            {/* Kolom yang baru dibuat */}
            {gsCreatedCols.length > 0 && (
              <div className="mb-4 rounded-xl p-4" style={{ background: "#f0fdf4", border: "1px solid #86efac" }}>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 mt-0.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} style={{ color: "#16a34a" }}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <div>
                    <p className="text-xs font-semibold" style={{ color: "#15803d" }}>
                      Kolom berikut berhasil dibuat otomatis:
                    </p>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {gsCreatedCols.map(col => (
                        <span key={col} className="text-[11px] font-medium px-2 py-0.5 rounded-md"
                          style={{ background: "#dcfce7", color: "#15803d", border: "1px solid #86efac" }}>
                          {col}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Warning: perlu share ke service account */}
            {gsNeedShare && (
              <div className="mb-4 rounded-xl p-4" style={{ background: "#fffbeb", border: "1px solid #fcd34d" }}>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 mt-0.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} style={{ color: "#d97706" }}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.962-.833-2.732 0L4.07 16.5c-.77.833.192 2.5 1.732 2.5z" />
                  </svg>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold mb-1" style={{ color: "#b45309" }}>
                      GSheet belum bisa diakses oleh sistem
                    </p>
                    <p className="text-xs mb-2" style={{ color: "#92400e" }}>
                      Share spreadsheet kamu ke email berikut dengan akses <strong>Editor</strong>, lalu simpan ulang:
                    </p>
                    {gsServiceEmail && (
                      <div className="flex items-center gap-2 rounded-lg px-3 py-2"
                        style={{ background: "#fef3c7", border: "1px solid #fcd34d" }}>
                        <svg className="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2} style={{ color: "#d97706" }}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <code className="text-xs font-mono break-all" style={{ color: "#92400e" }}>
                          {gsServiceEmail}
                        </code>
                        <button
                          type="button"
                          onClick={() => navigator.clipboard.writeText(gsServiceEmail)}
                          className="ml-auto shrink-0 text-[10px] font-medium px-2 py-0.5 rounded"
                          style={{ background: "#fcd34d", color: "#92400e" }}>
                          Salin
                        </button>
                      </div>
                    )}
                    <p className="text-[11px] mt-2" style={{ color: "#92400e" }}>
                      Cara share: Buka spreadsheet → klik <strong>Share</strong> → masukkan email di atas → pilih <strong>Editor</strong> → klik <strong>Send</strong>
                    </p>
                  </div>
                </div>
              </div>
            )}

            <form onSubmit={handleUpdateGSheet} className="space-y-4">
              <Field label="URL Google Sheet">
                <input type="url" value={gsheetUrl} onChange={e => setGsheetUrl(e.target.value)}
                  placeholder="https://docs.google.com/spreadsheets/d/..."
                  className="w-full rounded-xl px-3 py-2.5 text-sm outline-none"
                  style={{ background: "var(--input-bg)", border: "1px solid var(--input-border)", color: "var(--text-primary)" }} />
              </Field>
              <Field label="Nama Sheet">
                <input type="text" value={gsheetSheet} onChange={e => setGsheetSheet(e.target.value)}
                  placeholder="RAW"
                  className="w-full rounded-xl px-3 py-2.5 text-sm outline-none"
                  style={{ background: "var(--input-bg)", border: "1px solid var(--input-border)", color: "var(--text-primary)" }} />
              </Field>
              <Btn loading={gsLoading} label="Simpan GSheet" loadingLabel="Menyimpan..." />
            </form>
          </div>
        )}

        {/* Ganti Password — non-superuser only */}
        {!isSuperuser && (
          <div className="rounded-2xl border p-6" style={{ background: "var(--bg-surface)", borderColor: "var(--border)" }}>
            <h2 className="text-sm font-bold mb-4" style={{ color: "var(--text-primary)" }}>Ganti Password</h2>
            {pwdError && <Alert type="error" msg={pwdError} />}
            {pwdSuccess && <Alert type="success" msg={`${pwdSuccess} Mengalihkan ke login...`} />}
            <form onSubmit={handleChangePassword} className="space-y-4">
              <Field label="Password Saat Ini">
                <input type="password" value={curPwd} onChange={e => setCurPwd(e.target.value)} required
                  placeholder="••••••••"
                  className="w-full rounded-xl px-3 py-2.5 text-sm outline-none"
                  style={{ background: "var(--input-bg)", border: "1px solid var(--input-border)", color: "var(--text-primary)" }} />
              </Field>
              <Field label="Password Baru">
                <input type="password" value={newPwd} onChange={e => setNewPwd(e.target.value)} required
                  placeholder="Min. 8 karakter"
                  className="w-full rounded-xl px-3 py-2.5 text-sm outline-none"
                  style={{ background: "var(--input-bg)", border: "1px solid var(--input-border)", color: "var(--text-primary)" }} />
              </Field>
              <Field label="Konfirmasi Password Baru">
                <input type="password" value={conPwd} onChange={e => setConPwd(e.target.value)} required
                  placeholder="Ulangi password baru"
                  className="w-full rounded-xl px-3 py-2.5 text-sm outline-none"
                  style={{ background: "var(--input-bg)", border: "1px solid var(--input-border)", color: "var(--text-primary)" }} />
              </Field>
              <Btn loading={pwdLoading || !!pwdSuccess} label="Ganti Password" loadingLabel="Menyimpan..." />
            </form>
          </div>
        )}

        {/* Logout */}
        <div className="rounded-2xl border p-6" style={{ background: "var(--bg-surface)", borderColor: "var(--border)" }}>
          <h2 className="text-sm font-bold mb-1" style={{ color: "var(--text-primary)" }}>Keluar</h2>
          <p className="text-xs mb-4" style={{ color: "var(--text-muted)" }}>
            Sesi kamu akan diakhiri dan kamu perlu login ulang.
          </p>
          <button onClick={handleLogout} disabled={loggingOut}
            className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-colors"
            style={{ background: loggingOut ? "var(--text-muted)" : "#ef4444", cursor: loggingOut ? "not-allowed" : "pointer" }}>
            {loggingOut ? "Keluar..." : "Logout"}
          </button>
        </div>

      </div>
    </div>
  );
}

// ── Helper components ─────────────────────────────────────────────────────────
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium mb-1.5" style={{ color: "var(--text-secondary)" }}>
        {label}
      </label>
      {children}
    </div>
  );
}

function Btn({ loading, label, loadingLabel }: { loading: boolean; label: string; loadingLabel: string }) {
  return (
    <button type="submit" disabled={loading}
      className="px-5 py-2.5 rounded-xl text-sm font-semibold text-white transition-colors"
      style={{ background: loading ? "var(--text-muted)" : "var(--accent)", cursor: loading ? "not-allowed" : "pointer" }}>
      {loading ? loadingLabel : label}
    </button>
  );
}

function Alert({ type, msg }: { type: "error" | "success"; msg: string }) {
  const colors = type === "error"
    ? { bg: "rgba(239,68,68,0.08)", text: "#ef4444", border: "rgba(239,68,68,0.3)" }
    : { bg: "rgba(16,185,129,0.08)", text: "#10b981", border: "rgba(16,185,129,0.3)" };
  return (
    <div className="mb-3 rounded-xl px-4 py-3 text-sm border"
      style={{ background: colors.bg, color: colors.text, borderColor: colors.border }}>
      {msg}
    </div>
  );
}