"""
db/models.py
Semua ORM model dalam satu file.
"""
import enum
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, DateTime, Enum, ForeignKey, Integer, String, Text, Float, func, JSON
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


# ── Enums ─────────────────────────────────────────────────────────────────────
class RoleEnum(str, enum.Enum):
    engineer = "engineer"
    ptl      = "ptl"
    mitra    = "mitra"

class SyncTypeEnum(str, enum.Enum):
    auto         = "auto"
    manual       = "manual"
    dashboard    = "dashboard"
    mitra_update = "mitra_update"
    ptl_own_sheet = "ptl_own_sheet"

class MismatchTypeEnum(str, enum.Enum):
    missing_in_engineer = "missing_in_engineer"
    missing_in_ptl      = "missing_in_ptl"

class ResetStatusEnum(str, enum.Enum):
    pending   = "pending"
    completed = "completed"
    cancelled = "cancelled"

class RoleConfigEnum(str, enum.Enum):
    mitra = "mitra"
    ptl   = "ptl"


# ── users ─────────────────────────────────────────────────────────────────────
class User(Base):
    __tablename__ = "users"

    id            : Mapped[uuid.UUID]           = mapped_column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    username      : Mapped[str]                 = mapped_column(String(50), unique=True, nullable=False, index=True)
    password_hash : Mapped[str]                 = mapped_column(String(255), nullable=False)
    nama_lengkap  : Mapped[str]                 = mapped_column(String(150), nullable=False, index=True)
    role          : Mapped[RoleEnum]            = mapped_column(Enum(RoleEnum), nullable=False)
    gsheet_url        : Mapped[Optional[str]]  = mapped_column(String(500), nullable=True)
    gsheet_sheet_name : Mapped[Optional[str]]  = mapped_column(String(100), nullable=True)
    is_active     : Mapped[bool]                = mapped_column(Boolean, default=True, nullable=False)
    created_at    : Mapped[datetime]            = mapped_column(DateTime(timezone=True), server_default=func.now())
    created_by    : Mapped[Optional[str]]       = mapped_column(String(50), nullable=True)

    refresh_tokens         : Mapped[list["RefreshToken"]]        = relationship(back_populates="user", cascade="all, delete-orphan")
    sync_logs              : Mapped[list["SyncLog"]]             = relationship(back_populates="ptl_user", foreign_keys="SyncLog.ptl_user_id")
    sync_mismatches        : Mapped[list["SyncMismatch"]]        = relationship(back_populates="ptl_user")
    password_reset_requests: Mapped[list["PasswordResetRequest"]]= relationship(back_populates="user", cascade="all, delete-orphan")
    presets                : Mapped[list["UserPreset"]]          = relationship(back_populates="user", cascade="all, delete-orphan")
    column_config          : Mapped[Optional["UserColumnConfig"]] = relationship(back_populates="user", uselist=False, cascade="all, delete-orphan")


# ── refresh_tokens ────────────────────────────────────────────────────────────
class RefreshToken(Base):
    __tablename__ = "refresh_tokens"

    id         : Mapped[int]                 = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id    : Mapped[uuid.UUID]           = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    token_hash : Mapped[str]                 = mapped_column(String(255), nullable=False, index=True)
    issued_at  : Mapped[datetime]            = mapped_column(DateTime(timezone=True), server_default=func.now())
    expires_at : Mapped[datetime]            = mapped_column(DateTime(timezone=True), nullable=False)
    is_revoked : Mapped[bool]                = mapped_column(Boolean, default=False, nullable=False)
    revoked_at : Mapped[Optional[datetime]]  = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship(back_populates="refresh_tokens")


# ── superuser refresh_tokens ─────────────────────────────────────────────────
class SuperuserRefreshToken(Base):
    """Refresh token persisten untuk superuser yang tidak memiliki row di users."""
    __tablename__ = "superuser_refresh_tokens"

    id         : Mapped[int]                = mapped_column(Integer, primary_key=True, autoincrement=True)
    username   : Mapped[str]                = mapped_column(String(50), nullable=False, index=True)
    token_hash : Mapped[str]                = mapped_column(String(255), nullable=False, unique=True, index=True)
    issued_at  : Mapped[datetime]            = mapped_column(DateTime(timezone=True), server_default=func.now())
    expires_at : Mapped[datetime]            = mapped_column(DateTime(timezone=True), nullable=False)
    is_revoked : Mapped[bool]               = mapped_column(Boolean, default=False, nullable=False)
    revoked_at : Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)


# ── role_table_config ─────────────────────────────────────────────────────────
class RoleTableConfig(Base):
    __tablename__ = "role_table_config"

    id               : Mapped[int]            = mapped_column(Integer, primary_key=True, autoincrement=True)
    role             : Mapped[RoleConfigEnum] = mapped_column(Enum(RoleConfigEnum), nullable=False, unique=True)
    visible_columns  : Mapped[list]           = mapped_column(JSON, nullable=False, default=list)
    editable_columns : Mapped[list]           = mapped_column(JSON, nullable=False, default=list)
    updated_by       : Mapped[str]            = mapped_column(String(50), nullable=False, default="system")
    updated_at       : Mapped[datetime]       = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


# ── sync_log ──────────────────────────────────────────────────────────────────
class SyncLog(Base):
    __tablename__ = "sync_log"

    id            : Mapped[int]                 = mapped_column(Integer, primary_key=True, autoincrement=True)
    ptl_user_id   : Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    id_pa         : Mapped[str]                 = mapped_column(String(100), nullable=False, index=True)
    field_changed : Mapped[str]                 = mapped_column(String(100), nullable=False)
    old_value     : Mapped[Optional[str]]       = mapped_column(Text, nullable=True)
    new_value     : Mapped[Optional[str]]       = mapped_column(Text, nullable=True)
    sync_type     : Mapped[SyncTypeEnum]        = mapped_column(Enum(SyncTypeEnum), nullable=False)
    synced_at     : Mapped[datetime]            = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)
    synced_by     : Mapped[Optional[str]]       = mapped_column(String(50), nullable=True)

    ptl_user: Mapped[Optional["User"]] = relationship(back_populates="sync_logs", foreign_keys=[ptl_user_id])


# ── sync_mismatch ─────────────────────────────────────────────────────────────
class SyncMismatch(Base):
    __tablename__ = "sync_mismatch"

    id            : Mapped[int]                  = mapped_column(Integer, primary_key=True, autoincrement=True)
    ptl_user_id   : Mapped[uuid.UUID]            = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    id_pa         : Mapped[str]                  = mapped_column(String(100), nullable=False)
    mismatch_type : Mapped[MismatchTypeEnum]     = mapped_column(Enum(MismatchTypeEnum), nullable=False)
    detected_at   : Mapped[datetime]             = mapped_column(DateTime(timezone=True), server_default=func.now())
    resolved_at   : Mapped[Optional[datetime]]   = mapped_column(DateTime(timezone=True), nullable=True)
    is_dismissed  : Mapped[bool]                 = mapped_column(Boolean, default=False, nullable=False)
    dismissed_by  : Mapped[Optional[str]]        = mapped_column(String(50), nullable=True)
    dismissed_at  : Mapped[Optional[datetime]]   = mapped_column(DateTime(timezone=True), nullable=True)

    ptl_user: Mapped["User"] = relationship(back_populates="sync_mismatches")


# ── audit_log ─────────────────────────────────────────────────────────────────
class AuditLog(Base):
    __tablename__ = "audit_log"

    id         : Mapped[int]            = mapped_column(Integer, primary_key=True, autoincrement=True)
    actor      : Mapped[str]            = mapped_column(String(50), nullable=False, index=True)
    actor_role : Mapped[str]            = mapped_column(String(20), nullable=False)
    action     : Mapped[str]            = mapped_column(String(100), nullable=False, index=True)
    target     : Mapped[Optional[str]]  = mapped_column(String(150), nullable=True)
    ip_address : Mapped[Optional[str]]  = mapped_column(String(45), nullable=True)
    user_agent : Mapped[Optional[str]]  = mapped_column(Text, nullable=True)
    detail     : Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    created_at : Mapped[datetime]       = mapped_column(DateTime(timezone=True), server_default=func.now(), index=True)


# ── password_reset_requests ───────────────────────────────────────────────────
class PasswordResetRequest(Base):
    __tablename__ = "password_reset_requests"

    id           : Mapped[int]                  = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id      : Mapped[uuid.UUID]            = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    status       : Mapped[ResetStatusEnum]      = mapped_column(Enum(ResetStatusEnum), nullable=False, default=ResetStatusEnum.pending)
    requested_at : Mapped[datetime]             = mapped_column(DateTime(timezone=True), server_default=func.now())
    completed_at : Mapped[Optional[datetime]]   = mapped_column(DateTime(timezone=True), nullable=True)
    completed_by : Mapped[Optional[str]]        = mapped_column(String(50), nullable=True)

    user: Mapped["User"] = relationship(back_populates="password_reset_requests")

# ── user_presets ──────────────────────────────────────────────────────────────
class UserPreset(Base):
    """
    Preset kolom tabel per user.
    scope: 'engineer' | 'ptl'
    activePresetId tetap di localStorage.
    """
    __tablename__ = "user_presets"

    id         : Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id    : Mapped[uuid.UUID]     = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    scope      : Mapped[str]           = mapped_column(String(20), nullable=False)
    name       : Mapped[str]           = mapped_column(String(100), nullable=False)
    columns    : Mapped[list]          = mapped_column(JSON, nullable=False, default=list)
    widths     : Mapped[dict]          = mapped_column(JSON, nullable=True, default=dict)
    created_at : Mapped[datetime]      = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at : Mapped[datetime]      = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship(back_populates="presets")


# ── user_column_config ────────────────────────────────────────────────────────
class UserColumnConfig(Base):
    """
    Konfigurasi kolom editable per user (Engineer).
    Satu baris per user — upsert saat update.
    """
    __tablename__ = "user_column_config"

    id                   : Mapped[int]       = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id              : Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True)
    editable_columns     : Mapped[list]      = mapped_column(JSON, nullable=False, default=list)
    ptl_editable_columns : Mapped[list]      = mapped_column(JSON, nullable=False, default=list, server_default="[]")
    updated_at           : Mapped[datetime]  = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

    user: Mapped["User"] = relationship(back_populates="column_config")

# ── pa_records ────────────────────────────────────────────────────────────────
class PARecord(Base):
    """
    Data PA Engineer dari GSheet yang sudah dimigrasi ke PostgreSQL.
    GSheet tetap sebagai source of truth — tabel ini adalah cache/replica.
    gsheet_row = nomor baris di GSheet (untuk write-back status).
    """
    __tablename__ = "pa_records"

    id               : Mapped[int]             = mapped_column(Integer, primary_key=True, autoincrement=True)

    # Identitas
    id_pa            : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True,  index=True)
    node             : Mapped[Optional[str]]   = mapped_column(String(20),  nullable=True)
    id_permohonan    : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True)
    service_id       : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True)

    # Produk & Layanan
    nama_produk      : Mapped[Optional[str]]   = mapped_column(Text,        nullable=True)
    jenis_layanan    : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True)
    kategori_layanan : Mapped[Optional[str]]   = mapped_column(String(100), nullable=True)
    segmentasi       : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True)
    kategori_customer: Mapped[Optional[str]]   = mapped_column(String(100), nullable=True)
    kategori_owner   : Mapped[Optional[str]]   = mapped_column(String(100), nullable=True)
    bandwidth        : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True)

    # Lokasi
    alamat           : Mapped[Optional[str]]   = mapped_column(Text,        nullable=True)
    kp_node          : Mapped[Optional[str]]   = mapped_column(String(100), nullable=True, index=True)
    latitude         : Mapped[Optional[float]] = mapped_column(Float,       nullable=True)
    longitude        : Mapped[Optional[float]] = mapped_column(Float,       nullable=True)

    # Customer
    nama_customer    : Mapped[Optional[str]]   = mapped_column(Text,        nullable=True)

    # Tanggal
    tgl_terbit_pa    : Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)
    tgl_bai          : Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)
    tgl_upload_bai   : Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)

    # Jenis & Status
    jenis_pekerjaan  : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True, index=True)
    nomor_io         : Mapped[Optional[str]]   = mapped_column(String(50),  nullable=True)
    status_pa        : Mapped[Optional[str]]   = mapped_column(String(100), nullable=True, index=True)
    kategori_status  : Mapped[Optional[str]]   = mapped_column(String(100), nullable=True)
    kategori_progres : Mapped[Optional[str]]   = mapped_column(String(200), nullable=True)
    detail_progres   : Mapped[Optional[str]]   = mapped_column(Text,        nullable=True)
    progress_update  : Mapped[Optional[str]]   = mapped_column(Text,        nullable=True)

    # Aging
    aging_pa         : Mapped[Optional[int]]   = mapped_column(Integer,     nullable=True)
    aging_non_sc     : Mapped[Optional[float]] = mapped_column(Float,       nullable=True)
    aging_sc         : Mapped[Optional[float]] = mapped_column(Float,       nullable=True)

    # Tim
    nama_ptl         : Mapped[Optional[str]]   = mapped_column(String(200), nullable=True)
    nama_sales       : Mapped[Optional[str]]   = mapped_column(String(200), nullable=True)
    ptl_update       : Mapped[Optional[str]]   = mapped_column(String(200), nullable=True)

    # Metadata sync
    gsheet_row       : Mapped[int]             = mapped_column(Integer,     nullable=False, unique=True)
    synced_at        : Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)
    updated_at       : Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=False), nullable=True)


# ── dashboard_settings ──────────────────────────────────────────────────────────
class DashboardSetting(Base):
    """
    Konfigurasi dashboard yang bisa diedit superadmin via UI.
    Dibaca via settings_cache.py (TTL 5 menit) — tidak query DB setiap request.
    """
    __tablename__ = "dashboard_settings"

    id          : Mapped[int]           = mapped_column(Integer, primary_key=True, autoincrement=True)
    key         : Mapped[str]           = mapped_column(String(100), unique=True, nullable=False, index=True)
    value       : Mapped[str]           = mapped_column(Text, nullable=False)
    value_type  : Mapped[str]           = mapped_column(String(20), nullable=False, default="string")  # string | number | boolean | json
    category    : Mapped[str]           = mapped_column(String(50), nullable=False, index=True)
    label       : Mapped[str]           = mapped_column(String(200), nullable=False)
    description : Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    is_editable : Mapped[bool]          = mapped_column(Boolean, nullable=False, default=True)
    updated_by  : Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    updated_at  : Mapped[datetime]      = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
